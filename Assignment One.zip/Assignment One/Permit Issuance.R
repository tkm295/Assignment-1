library(tidyverse)
library(janitor)
library(fs)
library(dbplyr)
library(ggplot2)
library(tidyr)
library(tidycensus)


full_api_url <- URLencode("https://data.cityofnewyork.us/resource/ipu4-2q9a.csv?$query=SELECT * 
                          WHERE issuance_date>='2013-01-01T00:00:00.000' AND job_type='NB'LIMIT 100000")

#Used API to pull large data set from NYC Open Data. 
#I then used the select function to sort it by all new building permits after 2013-- the year after Hurricane Sandy. 
#I also raised the limit to 100,000.


NB_Permits_clean <- read_csv(full_api_url) %>%
  select(borough, bldg_type, residential, issuance_date)

#Read the csv into new title.
#Reduced the data down to necessary variables for my research question.

NB_Permits_mutated <- NB_Permits_clean %>%
  mutate(
    family_residential = ifelse(bldg_type == 1 & residential == "YES", TRUE, FALSE), #Building Type 1 is residential 1-3 family homes and Building Type 2 is denser housing.
    multi_dwelling_residential = ifelse(bldg_type == 2 & residential == "YES", TRUE, FALSE),
    non_residential = ifelse(residential == "NA", TRUE, FALSE)
  ) %>%
  mutate(
    family_residential = coalesce(family_residential, FALSE),
    multi_dwelling_residential = coalesce(multi_dwelling_residential, FALSE),
    non_residential = coalesce(non_residential, TRUE)
  )

#I mutated the building type and residential columns to create three new columns: 
#family residential, multi-dwelling, and non-residential.
#I found that some were turning up null values,
#so I used coalesce to turn them into false values for Family Residential and Multi-Dwelling,
#and true values for Non-Residential.

NB_summarized <- NB_Permits_mutated %>%
  group_by(borough) %>%
  summarize(
    quantity_family_res = sum(family_residential),
    quantity_multi_dwelling = sum(multi_dwelling_residential),
    quantity_non_res = sum(non_residential)
  )
            
#I used group by and summarize to find the count permits issued for 1-3 Family Homes, Multi-Dwelling Residences, and Non-Residential buildings by borough.

NB_summarized_long <- NB_summarized %>%
  pivot_longer(cols = c(quantity_family_res, quantity_multi_dwelling, quantity_non_res),
               names_to = "building_type",
               values_to = "Count")

#Used pivot longer in preparation for graphing.
  
NB_summarized_for_graphing <- NB_summarized_long %>%
  mutate(
  labels = #Added a new column with neat category labels
    case_when(
      building_type == 'quantity_family_res' ~ "Residential Family Home",
      building_type =='quantity_multi_dwelling' ~ "Multi-Dwelling Residences",
      building_type =='quantity_non_res' ~ "Non-Residential Buildings"
      ))

NB_summarized_for_graphing$labels <- factor(
  NB_summarized_for_graphing$labels, 
  levels = c("Residential Family Home", 
             "Multi-Dwelling Residences", 
             "Non-Residential Buildings"))

#Reordered the labels so the graph would show Residential Family Homes, then Multi-Dwelling, and then Non-Residential.

NB_summarized_for_graphing$borough <- factor(
  NB_summarized_for_graphing$borough, 
  levels = c("BROOKLYN", 
             "QUEENS",
             "MANHATTAN",
             "BRONX",
             "STATEN ISLAND")
)

#Reordered the boroughs so they were in order from most populous (Brooklyn) to least (Staten Island).

NB_borough_graph <- ggplot(NB_summarized_for_graphing) +
 aes(x = borough, y = Count, fill = labels) +
  geom_bar(position = "dodge", stat = "identity") + #used dodge so they'd be side-by-side
  labs(title = "New Building Permits Issued by Building Type and Borough", 
       subtitle = "A look at New Development in the 5 Boroughs (2013 - 2020)",
       x = "Borough",
       y="Permits Issued for New Buildings",
       caption = "Source: NYC Open Data: Department of Buildings",
       fill = "Building Type") + #Changed Legend title
  theme_classic() +
  scale_y_continuous(expand = c(0,0), limits = c(0,250)) #fixed scale to place zero directly on x-axis.Changed upper limit to be 250.

#Bar graph showing Permit type issued by Borough.

#This bar graph will show the same data, but separated out by building type.
NB_borough_graph_2 <- ggplot(NB_summarized_for_graphing) +
  aes(x = borough, y = Count, fill = borough, colors = ) +
  geom_bar(position = "dodge", stat = "identity") + #used dodge so they'd be side-by-side
  labs(title = "New Building Permits Issued by Building Type and Borough", 
       subtitle = "A look at New Development in the 5 Boroughs (2013 - 2020)",
       x = "Borough",
       y="Permits Issued for New Buildings",
       caption = "Source: NYC Open Data: Department of Buildings",
       fill = "Borough") +
  facet_wrap(~ labels) + #facet-wrap'd it to separate it out by type of New Building.
  theme_bw() 
  

#Now I will be creating a new data set to measure types of permits issued over time for all of New York City.

NB_permits_over_time <- NB_Permits_mutated %>%
  mutate(permit_type_label = case_when(
    family_residential ~ "Family Residential",
    multi_dwelling_residential ~ "Multi-Dwelling Residential",
    non_residential ~ "Non-Residential"
    )) %>%
  select(issuance_date, permit_type_label) #Created a new label row for permit type.

NB_permits_over_time <- NB_permits_over_time %>%
  mutate(year = lubridate::year(issuance_date)) %>% #Used lubridate to sort by year due to the low number of permits overall.
  group_by(year, permit_type_label) %>% #group by to show how many permits of each type were issued each year.
  summarize(permits_issued = n())


ggplot(NB_permits_over_time, aes(x = year, y = permits_issued, color = permit_type_label)) +
  geom_line() +
  labs(
    title = "Permits Issued Over Time",
    x = "Issuance Date",
    y = "Count of Permits Issued",
    color = "Permit Type"
  ) 

ggplot(NB_permits_over_time, aes(x = year, y = permits_issued, fill = permit_type_label)) +
  geom_bar(stat = "identity") +
  labs(
    title = "Permits Issued Over Time by Permit Type",
    x = "Year",
    y = "Count of Permits Issued",
    fill = "Permit Type"
  ) +
  theme_minimal()

#Try for comparison against population.

census_api_key("2558c6e371f819253fcde2f54a73fbaeb75f528b", TRUE)

pop_data <- get_acs(
  geography = "county", #Chose the county level since I am comparing boroughs.
  variables = c(
    total_population = "B01003_001" #this variable is for total population
    ),
  state =  "New York",
  year = 2020,
  survey = "acs5" 
) %>%
  filter(
    NAME == "Kings County, New York" |
      NAME == "Queens County, New York" |
      NAME == "New York County, New York" |
      NAME == "Bronx County, New York" |
      NAME == "Richmond County, New York"
  ) %>%
  clean_names()


pop_data <- pop_data %>%
  mutate(name = tolower(gsub(" County, New York", "", name))) %>% #had to change format of county to boroughs to join data.
  rename(borough = name) %>% #Made column more specific
  mutate(borough = case_when(
    borough == "new york"~ "manhattan", 
    borough == "richmond"~ "staten island",
    borough == "kings"~ "brooklyn",
    TRUE ~ borough
    ))


NB_summarized_for_graphing <- NB_summarized_for_graphing %>% #Made casing unified for original data set.
  mutate(borough = tolower(borough))

#Interjoined data by borough so I could have the total population of each borough.

NB_joined_data <- NB_summarized_for_graphing %>% 
  inner_join(pop_data, by = "borough") %>%
  select(borough, Count, estimate,labels, ) #Chose only the data I needed.

NB_joined_data <- NB_joined_data %>%
  rename(borough_pop = estimate) %>% #Changed name to borough_pop for clarification.
  mutate(pop_ratio = borough_pop / sum(c(1427056, 2576771, 1629153, 2270976, 475596))*100) #Created a ratio of population for each borough for easy comparison.

#Had to create labels to compare values by label instead of total count.

total_residential_count <- sum(NB_joined_data$Count[NB_joined_data$labels == "Residential Family Home"])
total_multi_dwelling <- sum(NB_joined_data$Count[NB_joined_data$labels == "Multi-Dwelling Residences"])
total_non_res <- sum(NB_joined_data$Count[NB_joined_data$labels == "Non-Residential Buildings"])

#Calculated each set into different data frames so I could see the percentage of population next to percentage of permit type issued.

NB_percent_family <- NB_joined_data %>%
  filter(labels == "Residential Family Home") %>%
  group_by(borough) %>%
  mutate(percentage = (Count / total_residential_count) * 100) %>% #Made into clear percentage by multiplying by 100.
  ungroup() 

NB_percent_multi <- NB_joined_data %>%
  filter(labels == "Multi-Dwelling Residences") %>%
  group_by(borough) %>%
  mutate(percentage = (Count / total_multi_dwelling) * 100) %>% 
  ungroup() 

NB_percent_non_res <- NB_joined_data %>%
  filter(labels == "Non-Residential Buildings") %>%
  group_by(borough) %>%
  mutate(percentage = (Count / total_non_res) * 100) %>% 
  ungroup()
